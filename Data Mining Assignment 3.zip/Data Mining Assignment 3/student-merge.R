# Library in use
library(ISLR)
library(tree)
library(dplyr)
library(readr)
library(party)
library(rpart)
library(rpart.plot)
library(ROCR)
library(C50)
library(gmodels)
library(e1071)
library(caret)
library(neuralnet)

d1=read.table("student-mat.csv",sep=";",header=TRUE)
d2=read.table("student-por.csv",sep=";",header=TRUE)

d3=merge(d1,d2,by=c("school","sex","age","address","famsize","Pstatus","Medu","Fedu","Mjob","Fjob","reason","nursery","internet"))
print(nrow(d3)) # 382 students

# Read dataset
df<-read.csv(file="student-mat.csv",header=TRUE, sep=";", stringsAsFactors=F)

# Pre-processing 
duplicated(df) #repeated row
unique(df[duplicated(df),]) #row diff,values same
View(unique(df)) #show duplicated data removed table
View(na.omit(df)) #View data without NA value
na.omit(df)

# Rename column
colnames(df) <- c("school" ,"sex" , "age" ,"address" , "family_size" ,"parent_cohabitation_status", "mother_education_level","father_education_level" ,"mother_job" , "father_job" ,  "reason","guardian","traveltime", "studytime","past_failures","school_support","family_support" , "paid_classes" , "activities","nursery","higher_education_interest" ,"internet" ,  "relationship","family_relationship" ,"freetime", "friends_hangout","workday_alcohol","weekend_alcohol" , "health","absences" , "G1" ,"G2" ,"G3")

df$parent_cohabitation_status[df$parent_cohabitation_status=="T"]<-"living together"
df$parent_cohabitation_status[df$parent_cohabitation_status=="A"]<-"apart"

df$family_relationship[df$family_relationship=="1"]<-"very bad"
df$family_relationship[df$family_relationship=="2"]<-"bad"
df$family_relationship[df$family_relationship=="3"]<-"moderate"
df$family_relationship[df$family_relationship=="4"]<-"good"
df$family_relationship[df$family_relationship=="5"]<-"excellent"

df$friends_hangout[df$friends_hangout=="1"]<-"very low"
df$friends_hangout[df$friends_hangout=="2"]<-"low"
df$friends_hangout[df$friends_hangout=="3"]<-"sometimes"
df$friends_hangout[df$friends_hangout=="4"]<-"high"
df$friends_hangout[df$friends_hangout=="5"]<-"very high"

df$workday_alcohol[df$workday_alcohol=="1"]<-"very low"
df$workday_alcohol[df$workday_alcohol=="2"]<-"low"
df$workday_alcohol[df$workday_alcohol=="3"]<-"sometimes"
df$workday_alcohol[df$workday_alcohol=="4"]<-"high"
df$workday_alcohol[df$workday_alcohol=="5"]<-"very high"

df$weekend_alcohol[df$weekend_alcohol=="1"]<-"very low"
df$weekend_alcohol[df$weekend_alcohol=="2"]<-"low"
df$weekend_alcohol[df$weekend_alcohol=="3"]<-"sometimes"
df$weekend_alcohol[df$weekend_alcohol=="4"]<-"high"
df$weekend_alcohol[df$weekend_alcohol=="5"]<-"very high"

# Create new table from dataset
data <-select(df, sex, age, parent_cohabitation_status, activities , internet, relationship, family_relationship, friends_hangout, workday_alcohol, weekend_alcohol)

range(df$G3)

# Total pass and fail
table(df$final_result)

# Change marks to pass fail
df$final_result <- NULL
df$final_result <- factor(ifelse(df$G3 >= 10,"pass", "fail"))

# Add column for pass fail
data = data.frame(data, df$final_result)


set.seed(2)
train <- sample(1:nrow(data),199)
test = -train
training_data = data[train,]
testing_data = data[test,]

# Percentage for training data pass fail
prop.table(table(training_data$df.final_result))

# Percentage for testing data pass fail
prop.table(table(testing_data$df.final_result))

#  Selecting all columns for data input except the one containing final result
tree_model <- C5.0(training_data[-11], training_data$df.final_result)
tree_model
summary(tree_model)


# Testing model
pred <- predict(tree_model, testing_data)


CrossTable(testing_data$df.final_result, pred,
           prop.chisq = FALSE, prop.c = FALSE, prop.r = FALSE,
           dnn = c('actual passing rate', 'predicted passing rate'))

# Calculates cross-tabulation
confusionMatrix(pred, testing_data$df.final_result)


# plot 1
rtree_fit <- rpart(df.final_result ~ ., 
                   data = training_data,  method = 'class') 
rpart.plot(rtree_fit)

# plot 2
rpart.plot(rtree_fit,varlen = 4, extra = 2)

# plot 3
tree2 <- rpart(df.final_result ~ . , data = training_data, method = 'class')
prp(tree2,varlen = 4, extra = 2)


# naive bayes classifier

classifier <- naiveBayes(training_data$df.final_result ~ ., data = training_data[-11])
classifier

prediction <- predict(classifier, testing_data)
prediction

pred2 <- predict(tree_model, testing_data)
CrossTable(testing_data$df.final_result, pred2, 
           prop.chisq = FALSE,prop.c = FALSE, prop.r = FALSE, 
           dnn = c("actual passing rate","predicted passing rate"))
confusionMatrix(pred2,testing_data$df.final_result)
